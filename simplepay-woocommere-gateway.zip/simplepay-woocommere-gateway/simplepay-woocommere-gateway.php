<script src="https://checkout.simplepay.ng/simplepay.js"></script>



<?php

/*
  Plugin Name: simplepaypay WooCommerce Payment Plugin
  Plugin URI: http://https://github.com/chicodes/
  Description: simplepay Payment Processing
  Version: 1.0
  Author: Akagha Chinaka
  Author URI: https://web.facebook.com/akaghachinaka1
 */

if (!defined('ABSPATH')) {
    exit;
}
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    exit;
}

add_action('plugins_loaded', 'woocommerce_simplepay_init', 0);

function woocommerce_simplepay_init() {
    if (!class_exists('WC_Payment_Gateway'))
        return;

    class WC_Simplepay extends WC_Payment_Gateway {

        public function __construct() {
            $this->simplepay_errors = new WP_Error();

            $this->id = 'simplepay';
            $this->medthod_title = 'SimplepayPayment';
            $this->icon = apply_filters('woocommerce_simplepay_icon', plugins_url('assets/images/logo.png', __FILE__));
            $this->has_fields = false;

            $this->init_form_fields();
            $this->init_settings();


            $this->simplepay_enviroment_status = $this->settings['simplepay_enviroment_status'];
            $this->title = $this->settings['title'];
            $this->description = $this->settings['description'];
            $this->simplepay_mert_id = ($this->simplepay_enviroment_status=='yes')?"demo":$this->settings['simplepay_mert_id'];
            $this->simplepay_mert_ref = $this->setings['simplepay_mert_ref'];
            $this->simplepay_store_id = $this->settings['simplepay_store_id'];
            $this->simplepay_tranx_curr = $this->settings['simplepay_tranx_curr'];
            $this->hashkey = $this->settings['hashkey'];
            $this->simplepay_tranx_query_url = $this->settings['simplepay_tranx_query_url'];
            $this->simplepay_payment_type = $this->settings['simplepay_payment_type'];
            


            $this->posturl = '';
            $this->geturl = '';

            $this->msg['message'] = "";
            $this->msg['class'] = "";

            if (isset($_POST["token"])) {
                $this->check_simplepay_response();
            }

            if (version_compare(WOOCOMMERCE_VERSION, '2.0.0', '>=')) {
                add_action('woocommerce_update_options_payment_gateways_' . $this->id, array(&$this, 'process_admin_options'));
            } else {
                add_action('woocommerce_update_options_payment_gateways', array(&$this, 'process_admin_options'));
            }

            add_action('woocommerce_receipt_simplepay', array(&$this, 'receipt_page'));
        }

        function receipt_page($order) {
            global $woocommerce;
            $items = $woocommerce->cart->get_cart();
            $item_rows = "";
            $currency = get_woocommerce_currency_symbol();
            $css = "<style>
                    .label-info{
                        background-color: green;
                        color: #f4f4f4;
                        padding: 5px;
                    }
                    tbody tr td { border-bottom: 1px solid; }
                    tbody tr{
                        font-size:14px;
                    }
                    thead{
                        font-size:16px;
                    }
                    tbody tr td{
                        padding: 10px 0px;
                    }tr:nth-child(even) {
                        background-color: #f4f4f4;
                    }
                    tfoot tr td:nth-child(1){
                        font-weight: bold;
                        font-size: 22px;
                        padding: 10px 0px 0px 10px;
                    }
                    </style>";
            echo $css;
            $price_total = 0;

            $order_data = new WC_Order($order);
            $shipping = $order_data->get_shipping_method();
            $shipping_rate = $order_data->get_total_shipping();
 
            foreach ($items as $item => $values) {
                $_product = $values['data']->post;
                $price = get_post_meta($values['product_id'], '_price', true) * $values['quantity'];
                $price_total += $price;
                $item_rows .= '<tr><td>' . $_product->post_title . '</td><td>' . $values['quantity'] . '</td><td>' . $price . '</td> </tr>'; 
            }
            $item_rows .= "<tr><td><b><i>Sub Total</i></b></td><td></td><td>" . $price_total . "</td></tr>";
            if ($shipping && $shipping <> "") {
                $item_rows .= "<tr><td><b><i>Shipping(" . $shipping
                        . ")</i></b></td><td></td><td>" . $shipping_rate
                        . "</td></tr>";
            }
            if ($shipping_rate > 0) {
                $price_total += $shipping_rate;
            }
            $confirmation_table = '<p><span class="label-info">Please review your order then click on "Pay via simplepay" button</span></p>
                                    <br><h2>Your Order</h2>
                                    <table><thead><tr><th>Product</th><th>Qty</th><th>Amount(' . trim($currency) . ')</th></tr><thead>
                                    <tbody>' . $item_rows . '</tbody>
                                    <tfoot><tr><td><b>Grand Total</b></td><td></td><td><b>' . $currency . $price_total .
                    '</b></td></tr></tfoot></table>';

            echo $confirmation_table;
            echo $this->generate_simplepay_form($order);
        }

        public function generate_simplepay_items_args(){
            global $woocommerce;
            $items = $woocommerce->cart->get_cart();

            $simplepay_items_purchased = array();
            $simplepay_item_count = 0;
            foreach ($items as $item => $values) {
                $_product = $values['data']->post;
                $price = get_post_meta($values['product_id'], '_price', true) * $values['quantity'];
                $simplepay_item_purchased = array();
                $simplepay_item_purchased["item_".++$simplepay_item_count] = $_product->post_title;
                $simplepay_item_purchased["description_".$simplepay_item_count] = $_product->post_title;
                $simplepay_item_purchased["price_".$simplepay_item_count] = $price;
                $simplepay_items_purchased[] = $simplepay_item_purchased;
            }

            return $simplepay_items_purchased;
        }

        public function generate_simplepay_form($order_id) {
            global $woocommerce;

            $order = new WC_Order($order_id);
            $txnid = $order_id . '_' . date("ymds");

            $redirect_url = $woocommerce->cart->get_checkout_url();
            $simplepay_cust_id = $order->billing_email;

            $simplepay_hash = $this->simplepay_mert_id . $txnid . $order->order_total * 100 . $this->simplepay_tranx_curr
                    . $simplepay_cust_id . $redirect_url . $this->hashkey;
            $hash = hash('sha512', $simplepay_hash);

            $simplepay_args = array(
                'v_merchant_id' => $this->simplepay_mert_id,
                'merchant_ref'=>$this->simplepay_mert_ref.'#'.$txnid,
                'memo'=> '',

                //'developer_code' => $hash,
                //'store_id' => $this->simplepay_store_id,
                'total' => $order->order_total * 100, 
 
                'notify_url' => $redirect_url,
                'success_url'  => $redirect_url,
                'fail_url'  => $redirect_url,

                'cur' => $this->simplepay_tranx_curr,
                'simplepay_cust_id' => $simplepay_cust_id,   
                'simplepay_echo_data' => $order_id . ";" . $hash
            );

            $simplepay_args = array_merge($simplepay_args, $this->generate_simplepay_items_args());

            $simplepay_args_array = array();
            foreach ($simplepay_args as $key => $value) {
                $simplepay_args_array[] = "<input type='hidden' name='$key' value='$value'/>";
            }
            return '<form action="' . $redirect_url . '" method="post" id="simplepay_payment_form">
            ' . implode('', $simplepay_args_array) . '
            <input type="submit" class="button-alt" id="btn-checkout" value="' . __('Pay via simplepay', 'simplepay') . '" /> <a class="button cancel" href="' . $order->get_cancel_order_url() . '">' . __('Cancel order &amp; restore cart', 'simplepay') . '</a>
            <script type="text/javascript">
            
function processPayment (token) {
    // implement your code here - we call this after a token is generated

    // example:
    var form = jQuery(\'#simplepay_payment_form\');
    form.append(
        jQuery(\'<input />\', { name: \'token\', type: \'hidden\', value: token })
    );
    form.submit();
}

// Configure SimplePay\'s Gateway
var handler = SimplePay.configure({
   token: processPayment, // callback function to be called after token is received
   key: \'test_pu_demo\', // place your api key. Demo: test_pu_*. Live: pu_*
   image: \'http://\' // optional: an url to an image of your choice
});

function processSimplePayJSPayment(){
jQuery("body").block(
        {
            message: "<img src=\"' . plugins_url('assets/images/ajax-loader.gif', __FILE__) . '\" alt=\"redirecting...\" style=\"float:left; margin-right: 10px;\" />' . __('Thank you for your order. We are now redirecting you to Payment Gateway to make payment.', 'simplepay') . '",
                overlayCSS:
        {
            background: "#fff",
                opacity: 0.6
    },
    css: {
        padding:        20,
            textAlign:      "center",
            color:          "#555",
            border:         "3px solid #aaa",
            backgroundColor:"#fff",
            cursor:         "wait",
            lineHeight:"32px"
    }
    });
    jQuery("#simplepay_payment_form").submit();
    }
    jQuery("#submit_simplepay_payment_form").click(function (e) {
        e.preventDefault();
        processSimplePayJSPayment();
    });
</script>
            </form>


<script type="text/javascript">

jQuery("#btn-checkout").on("click", function (e) { // add the event to your "pay" button
    e.preventDefault();
  handler.open(SimplePay.CHECKOUT, // type of payment
    {
       email: "customer@store.com", // optional: users email
       phone: "+234*", // optional: users phone number
       description: "My Test Store Checkout 123-456", // a description of your choosing
       address: "31 Kade St, Abuja, Nigeria", // users address
       postal_code: "110001", // users postal code
       city: "Abuja", // users city
       country: "NG", // users country
       amount: "'.($order->order_total * 100).'", // value of the purchase, ₦ 1100
       currency: "NGN" // currency of the transaction
    }); 
});

</script>'

            ;
        }

        function init_form_fields() {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable', 'simplepay'),
                    'type' => 'checkbox',
                    'label' => __('Enable simplepay Payment Module.', 'simplepay'),
                    'default' => 'no'
                ),
                'title' => array(
                    'title' => __('Title:', 'simplepay'),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.', 'simplepay'),
                    'default' => __('simplepay Payment', 'simplepay')
                ),
                'description' => array(
                    'title' => __('Description:', 'simplepay'),
                    'type' => 'textarea',
                    'description' => __('This controls the description which the user sees during checkout.', 'simplepay'),
                    'default' => __('simplepay is a simplepay’s payment gateway which facilitates merchant collection from their website. It offers the options for local and international credit/debit cards, Bank Transfers from any Nigerian Bank as well as Mobile Money wallets and is constantly being extended to offer more payment options to your clients.', 'simplepay')
                ),
                'simplepay_mert_id' => array(
                    'title' => __('simplepay Merchant ID', 'simplepay'),
                    'type' => 'text',
                    'description' => __('This is the simplepay-wide unique identifier of merchant, assigned by simplepay and communicated to merchant by simplepay after merchant registration.')
                ),
                'simplepay_mert_ref' => array(
                    'title' => __('simplepay Merchant REF', 'simplepay'),
                    'type' => 'text',
                    'description' => __('This value will be returned with the confirmation results from the confirmation api. SimplePay doesnt need this value, it is used by the merchant to store any data he wishess to retrieve later with the transaction details.')
                ),
                'simplepay_store_id' => array(
                    'title' => __('simplepay Store Id', 'simplepay'),
                    'type' => 'text',
                    'description' => __('A unique store identifier which identifies a particular store a transaction was made.')
                ),
                'hashkey' => array(
                    'title' => __('Hash Key', 'simplepay'),
                    'type' => 'text',
                    'description' => __('Please note that the hash key will be provided by simplepay upon completing registration."')
                ),
                'simplepay_tranx_curr' => array(
                    'title' => __('Currency', 'simplepay'),
                    'type' => 'text',
                    'description' => __('This parameter represents the ISO currency code representing the currency in which the transaction is been carried out. Acceptable values Naira  - (566). USD  - (840)"')
                ),

                'simplepay_tranx_query_url' => array(
                    'title' => __('URL to query transaction status', 'simplepay'),
                    'type' => 'text',
                    'description' => __('This parameter represents URL to get the status of the transaction')
                ),

                'simple_pay_enviroment_status' => array(
                    'title' => __('Enable/Disable Demo', 'simplepay'),
                    'type' => 'checkbox',
                    'label' => __('Enable demo.', 'simplepay'),
                    'default' => 'no'
                ),

                'simplepay_payment_type' => array(
                    'title' => __('SimplePay.CHECKOUT/SimplePay.REMEMBER', 'simplepay'),
                    'type' => 'checkbox',
                    'label' => __('Select Payement Type.', 'simplepay'),
                    'default' => __('no'),
                    'description' => __('payment type should be chosen from available choices SimplePayCHECKOUT', 'SimplePay.REMEMBER'),
                ),

                'simplepay_api_key' => array(
                    'title' => __('API key supplied by simplepay', 'simplepay'),
                    'type' => 'text',
                    'description' => __('your api key -- sign up for one at SimplePay','simplepay'),
                )
            );
        }

        public function admin_options() {
            echo '<h3>' . __('simplepay Payment Gateway', 'simplepay') . '</h3>';
            echo '<p>' . __('simplepay is most popular payment simplepay for online shopping in Nigeria') . '</p>';
            echo '<table class="form-table">';
            $this->generate_settings_html();
            echo '</table>';
            wp_enqueue_script('simplepay_admin_option_js', plugin_dir_url(__FILE__) . 'assets/js/settings.js', array('jquery'), '1.0.1');
        }

        function payment_fields() {
            if ($this->description)
                echo wpautop(wptexturize($this->description));
        }

        function process_payment($order_id) {
            global $woocommerce;
            $order = new WC_Order($order_id);
            return array(
                'result' => 'success',
                'redirect' => add_query_arg(
                        'order', $order->id, add_query_arg(
                                'key', $order->order_key, get_permalink(get_option('woocommerce_pay_page_id'))
                        )
                )
            );
        }

        function showMessage($content) {
            return '<div class="box ' . $this->msg['class'] . '-box">' . $this->msg['message'] . '</div>' . $content;
        }

        function get_pages($title = false, $indent = true) {
            $wp_pages = get_pages('sort_column=menu_order');
            $page_list = array();
            if ($title)
                $page_list[] = $title;
            foreach ($wp_pages as $page) {
                $prefix = '';
                // show indented child pages?
                if ($indent) {
                    $has_parent = $page->post_parent;
                    while ($has_parent) {
                        $prefix .= ' - ';
                        $next_page = get_page($has_parent);
                        $has_parent = $next_page->post_parent;
                    }
                }
                // add to page list array array
                $page_list[$page->ID] = $prefix . $page->post_title;
            }
            return $page_list;
        }

        function check_simplepay_response() {
            global $woocommerce;
            $simplepay_echo_data = $_POST["simplepay_echo_data"];
            $data = explode(";", $simplepay_echo_data);
            $wc_order_id = $data[0];
            $order = new WC_Order($wc_order_id); 

            $simplepay_payment_token = $_POST["token"];
            $simplepay_payment_amount = $_POST["total"];
             
            try {  

                $remote_url = 'https://api.simplepay.ng/v1/payments/verify';
                $headers = array("authorization: Basic ".base64_encode("test_pr_demo:"),
                                    "cache-control: no-cache",
                                    "content-type: application/x-www-form-urlencoded",
                                    "postman-token: 0007cf51-57e0-2ed4-ead8-8a1c6de170f8");
                $postData = 'token='.$simplepay_payment_token.'&amount='.$simplepay_payment_amount.'&amount_currency=NGN';

                $curl = curl_init();
                curl_setopt_array($curl, array(
                  CURLOPT_URL => $remote_url,
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => "",
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_SSL_VERIFYPEER => false,
                  CURLOPT_TIMEOUT => 30,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => "POST",
                  CURLOPT_POSTFIELDS => $postData,
                  CURLOPT_HTTPHEADER => array(
                    "authorization: Basic dGVzdF9wcl9kZW1vOg==",
                    "cache-control: no-cache",
                    "content-type: application/x-www-form-urlencoded",
                    "postman-token: 0007cf51-57e0-2ed4-ead8-8a1c6de170f8"
                  ),
                ));

                $status_responce = curl_exec($curl);
                $err = curl_error($curl);
                curl_close($curl);
                
                /*
                if ($err) { 
                    $order->add_order_note('Error: ' . $e->getMessage());
                    wc_add_notice($err, "error");
                    $redirect_url = $order->get_cancel_order_url();
                    wp_redirect(html_entity_decode($redirect_url));
                    exit;
                }

                /* else {
                  echo $status_responce;
                }* /
                $opts = array('https'=>array('method'=>"POST", 'header' => $headers , 'content' => $postData,) ,
                                "ssl"=>array(  "verify_peer"=>true, "cafile" => __DIR__."\GeoTrust_Primary_CA.pem",
                                    'verify_depth'  => 5,
                                    'CN_match'      => 'api.simplepay.ng',
                                    'disable_compression' => true,
                                    'SNI_enabled'         => true,
                                    'ciphers'             => 'ALL!EXPORT!EXPORT40!EXPORT56!aNULL!LOW!RC4'
                                    ) );
                $context = stream_context_create($opts);
                $status_responce = file_get_contents($remote_url, false, $context);
                */

                $transaction_details= json_decode($status_responce); 

                
                $tranxid = $transaction_details->id;

                if ($transaction_details->response_code === 40000) {
                    #payment cancelled
                    $respond_desc = ""; // $_POST["simplepay_tranx_status_msg"];
                    $message_resp = "Your transaction was not successful." .
                            "<br>Reason: " . $respond_desc .
                            "<br>Transaction Reference: " . $tranxid;
                    $message_type = "error";
                    $order->add_order_note('simplepay payment failed: ' . $respond_desc);
                    $order->update_status('cancelled');
                    $redirect_url = $order->get_cancel_order_url();
                    wc_add_notice($message_resp, "error");
                }
                else if ($transaction_details->response_code === 30000) {
                    #payment pending
                    $respond_desc = ""; // $_POST["simplepay_tranx_status_msg"];
                    $message_resp = "Your transaction is pending." .
                            "<br>Reason: " . $respond_desc .
                            "<br>Transaction Reference: " . $tranxid;
                    $message_type = "error";
                    $order->add_order_note('simplepay payment is pending: ' . $respond_desc);
                    $order->update_status('pending');
                    $redirect_url = $order->get_cancel_order_url();
                    wc_add_notice($message_resp, "error");
                } 
                else if($transaction_details->response_code === 20000) {
                    wc_print_notices();
                    $mert_id = $this->vsimplepay_mert_id;
                    $hashkey = $this->hashkey;
                    $my_hash = hash("sha512", $mert_id . $tranxid . $hashkey);
                    
                    #payment successful
                    $respond_desc = ""; // $response_decoded->ResponseDescription;
                    $message_resp = "Approved Successful." .
                        "<br>" . $respond_desc .
                        "<br>Transaction Reference: " . $tranxid;
                    $message_type = "success";
                    $order->payment_complete();
                    $order->update_status('completed');
                    $order->add_order_note('Simplepay payment successful: ' . $message_resp);
                    $woocommerce->cart->empty_cart();
                    $redirect_url = $this->get_return_url($order);
                    wc_add_notice($message_resp, "success");
                    
                }
                else{ 
                    #payment failed
                    $respond_desc = "";// $response_decoded->ResponseDescription;
                    $message_resp = "Your transaction was not successful." .
                        "<br>Reason: " . $respond_desc .
                        "<br>Transaction Reference: " . $tranxid;
                    $message_type = "error";
                    $order->add_order_note('Simplepay payment failed: ' . $message_resp);
                    $order->update_status('cancelled');
                    $redirect_url = $order->get_cancel_order_url();
                    wc_add_notice($message_resp, "error");
                }

                $notification_message = array(
                    'message' => $message_resp,
                    'message_type' => $message_type
                );

                wp_redirect(html_entity_decode($redirect_url));
                exit;
            } catch (Exception $e) {
                $order->add_order_note('Error: ' . $e->getMessage());

                wc_add_notice($e->getMessage(), "error");
                $redirect_url = $order->get_cancel_order_url();
                wp_redirect(html_entity_decode($redirect_url));
                exit;
            }
        }

        static function add_simplepay_currency($currencies) {
            $currencies['Naira'] = __('Naira', 'woocommerce');
            $currencies['USD'] = __('US Dollar', 'woocommerce');
            return $currencies;
        }

        static function add_simplepay_currency_symbol($currency_symbol, $currency) {
            switch ($currency) {
                case 'Naira':
                    $currency_symbol = '₦ ';
                    break;
                case 'USD':
                    $currency_symbol = '$ ';
                    break;
            }
            return $currency_symbol;
        }

        static function woocommerce_add_simplepay_gateway($methods) {
            $methods[] = 'WC_Simplepay';
            return $methods;
        }

        // Add settings link on plugin page
        static function woocommerce_add_simplepay_settings_link($links) {
            $settings_link = '<a href="admin.php?page=wc-settings&tab=checkout&section=wc_simplepay">Settings</a>';
            array_unshift($links, $settings_link);
            return $links;
        }

    }

    $plugin = plugin_basename(__FILE__);

    add_filter('woocommerce_currencies', array('WC_Simplepay', 'add_simplepay_currency'));
    add_filter('woocommerce_currency_symbol', array('WC_Simplepay', 'add_simplepay_currency_symbol'), 10, 2);
    add_filter("plugin_action_links_$plugin", array('WC_Simplepay', 'woocommerce_add_simplepay_settings_link'));
    add_filter('woocommerce_payment_gateways', array('WC_Simplepay', 'woocommerce_add_simplepay_gateway'));
}
